const Example3 = [
    {
      id: 1,
      animal: 'cat',
      gender: 'male',
      height: 30
    },
    {
      id: 2,
      animal: 'dog',
      gender: 'female',
      height: 50
    },
    {
      id: 3,
      animal: 'bird',
      gender: 'male',
      height: 15
    },
    {
      id: 4,
      animal: 'cat',
      gender: 'female',
      height: 32
    },
    {
      id: 5,
      animal: 'dog',
      gender: 'male',
      height: 52
    },
    {
      id: 6,
      animal: 'bird',
      gender: 'female',
      height: 17
    },
    {
      id: 7,
      animal: 'cat',
      gender: 'male',
      height: 28
    },
    {
      id: 8,
      animal: 'dog',
      gender: 'female',
      height: 47
    },
    {
      id: 9,
      animal: 'bird',
      gender: 'male',
      height: 16
    },
    {
      id: 10,
      animal: 'cat',
      gender: 'female',
      height: 33
    },
    {
      id: 11,
      animal: 'dog',
      gender: 'male',
      height: 54
    },
    {
      id: 12,
      animal: 'bird',
      gender: 'female',
      height: 18
    },
    {
      id: 13,
      animal: 'cat',
      gender: 'male',
      height: 31
    },
    {
      id: 14,
      animal: 'dog',
      gender: 'female',
      height: 49
    },
    {
      id: 15,
      animal: 'bird',
      gender: 'male',
      height: 14
    }
  ];
  
  export default Example3;