const Example2 = [
    {
      id: 1,
      group: 1,
      color: 'red',
      isActive: true,
      score: 85
    },
    {
      id: 2,
      group: 1,
      color: 'blue',
      isActive: false,
      score: 78
    },
    {
      id: 3,
      group: 1,
      color: 'green',
      isActive: true,
      score: 90
    },
    {
      id: 4,
      group: 1,
      color: 'yellow',
      isActive: false,
      score: 60
    },
    {
      id: 5,
      group: 1,
      color: 'red',
      isActive: true,
      score: 88
    },
    {
      id: 6,
      group: 2,
      color: 'blue',
      isActive: false,
      score: 72
    },
    {
      id: 7,
      group: 2,
      color: 'green',
      isActive: true,
      score: 95
    },
    {
      id: 8,
      group: 2,
      color: 'red',
      isActive: false,
      score: 80
    },
    {
      id: 9,
      group: 2,
      color: 'yellow',
      isActive: true,
      score: 82
    },
    {
      id: 10,
      group: 2,
      color: 'blue',
      isActive: true,
      score: 76
    },
    {
      id: 11,
      group: 3,
      color: 'green',
      isActive: false,
      score: 89
    },
    {
      id: 12,
      group: 3,
      color: 'red',
      isActive: true,
      score: 90
    },
    {
      id: 13,
      group: 3,
      color: 'blue',
      isActive: false,
      score: 65
    },
    {
      id: 14,
      group: 3,
      color: 'yellow',
      isActive: true,
      score: 70
    },
    {
      id: 15,
      group: 3,
      color: 'green',
      isActive: true,
      score: 92
    }
  ];
  
  export default Example2;
  