const Example = [
  {
    id: 1,
    name: '김철수',
    age: 25,
    job: '개발자'
  },
  {
    id: 2,
    name: '이영희',
    age: 28,
    job: '디자이너'
  },
  {
    id: 3,
    name: '박민수',
    age: 32,
    job: '마케터'
  },
  {
    id: 4,
    name: '최유리',
    age: 24,
    job: '개발자'
  },
  {
    id: 5,
    name: '장현진',
    age: 29,
    job: '매니저'
  },
  {
    id: 6,
    name: '유재석',
    age: 34,
    job: '개발자'
  },
  {
    id: 7,
    name: '홍길동',
    age: 27,
    job: '디자이너'
  },
  {
    id: 8,
    name: '이수진',
    age: 30,
    job: '마케터'
  },
  {
    id: 9,
    name: '김태희',
    age: 31,
    job: '매니저'
  },
  {
    id: 10,
    name: '박보검',
    age: 26,
    job: '디자이너'
  }
];

export default Example;